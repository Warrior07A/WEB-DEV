## How to test
 - Install bun - https://bun.com/docs/installation
 - Run `bun install` in your terminal in this folder
 - Run your HTTP Server with mongo db in one terminal
 - Run bun test in another terminal with this folder open.

